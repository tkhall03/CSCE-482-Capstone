import Image from 'next/image'

export default function DocumentLine(){
    return (
        <div className="bg-aggie-maroon h-18 w-full flex justify-start">
            
        </div>
    );
}